package com.tareas.controller;

import com.tareas.model.TareaDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Map;

@WebServlet("/ReporteServlet")
public class ReporteServlet extends HttpServlet {

    private TareaDAO tareaDAO = new TareaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Obtener los datos de la BD
        Map<String, Integer> conteoPorEstado = tareaDAO.obtenerConteoPorEstado();

        // Enviar los datos al JSP
        request.setAttribute("conteoEstados", conteoPorEstado);
        request.getRequestDispatcher("reporte.jsp").forward(request, response);
    }
}

