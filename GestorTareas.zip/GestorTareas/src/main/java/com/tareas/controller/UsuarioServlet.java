package com.tareas.controller;

import com.tareas.model.Usuario;
import com.tareas.model.UsuarioDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/UsuarioServlet")
public class UsuarioServlet extends HttpServlet {

    private UsuarioDAO usuarioDAO = new UsuarioDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Evitar cacheo del navegador
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);

        HttpSession sesion = request.getSession(false);
        Usuario usuarioLogueado = (Usuario) sesion.getAttribute("usuario");

        if (usuarioLogueado == null || !"admin".equals(usuarioLogueado.getRol())) {
            response.sendRedirect("login.jsp");
            return;
        }

        String action = request.getParameter("action");
        String idStr = request.getParameter("id");

        if ("hacerAdmin".equals(action) && idStr != null) {
            int id = Integer.parseInt(idStr);
            usuarioDAO.convertirEnAdmin(id);
            response.sendRedirect("UsuarioServlet");
            return;
        }

        if ("hacerUsuario".equals(action) && idStr != null) {
    int id = Integer.parseInt(idStr);

    if (usuarioLogueado.getId() == id) {
        // Si el admin se convierte a usuario a sí mismo, cerrar sesión
        usuarioDAO.convertirEnUsuario(id);
        sesion.invalidate();
        response.sendRedirect("login.jsp");
        return;
    } else {
        usuarioDAO.convertirEnUsuario(id);
        response.sendRedirect("UsuarioServlet");
        return;
    }
}


        if ("eliminar".equals(action) && idStr != null) {
    int id = Integer.parseInt(idStr);

    // Validar si está intentando eliminarse a sí mismo
    if (usuarioLogueado.getId() == id) {
        sesion.setAttribute("error", "No puedes eliminarte a ti mismo.");
    } else if (usuarioDAO.tieneTareas(id)) {
        sesion.setAttribute("error", "No se puede eliminar el usuario porque tiene tareas asignadas.");
    } else {
        usuarioDAO.eliminarUsuario(id);
    }

    response.sendRedirect("UsuarioServlet");
    return;
}


        // Si hay error guardado en sesión, pasarlo a request
        String error = (String) sesion.getAttribute("error");
        if (error != null) {
            request.setAttribute("error", error);
            sesion.removeAttribute("error");
        }

        // Mostrar lista actualizada
        List<Usuario> usuarios = usuarioDAO.obtenerTodos();
        request.setAttribute("usuarios", usuarios);
        request.getRequestDispatcher("usuarios.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");

        if ("cambiarEstado".equals(accion)) {
            int id = Integer.parseInt(request.getParameter("idUsuario"));
            String nuevoEstado = request.getParameter("nuevoEstado");

            HttpSession sesion = request.getSession(false);
            Usuario usuarioLogueado = (Usuario) sesion.getAttribute("usuario");

            if (usuarioLogueado != null && usuarioLogueado.getId() == id && "inactivo".equals(nuevoEstado)) {
                // Guardar error en sesión para mostrarlo luego del redirect
                sesion.setAttribute("error", "No puedes desactivarte a ti mismo.");
            } else {
                usuarioDAO.cambiarEstado(id, nuevoEstado);
            }

            // Redirigir siempre, evita reenvío de formularios y problemas con el historial
            response.sendRedirect("UsuarioServlet");
        }
    }
}


