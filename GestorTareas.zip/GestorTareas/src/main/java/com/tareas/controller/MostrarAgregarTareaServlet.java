package com.tareas.controller;

import com.tareas.model.Usuario;
import com.tareas.model.UsuarioDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/MostrarAgregarTarea")
public class MostrarAgregarTareaServlet extends HttpServlet {

    private UsuarioDAO usuarioDAO = new UsuarioDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession sesion = request.getSession(false);
        if (sesion == null || sesion.getAttribute("usuario") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        Usuario usuario = (Usuario) sesion.getAttribute("usuario");

        // Si es admin, cargar la lista de usuarios activos
        if ("admin".equalsIgnoreCase(usuario.getRol())) {
            List<Usuario> usuarios = usuarioDAO.obtenerUsuariosActivos();
            request.setAttribute("usuarios", usuarios);
        }

        // Enviar al formulario de agregar tarea
        request.setAttribute("usuario", usuario); // necesario para <c:if> del JSP
        request.getRequestDispatcher("agregar_tarea.jsp").forward(request, response);
    }
}

