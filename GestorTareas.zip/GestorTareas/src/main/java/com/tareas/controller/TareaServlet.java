package com.tareas.controller;

import com.tareas.model.Tarea;
import com.tareas.model.TareaDAO;
import com.tareas.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/TareaServlet")
public class TareaServlet extends HttpServlet {

    private TareaDAO tareaDAO = new TareaDAO();

    @Override
protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    HttpSession sesion = request.getSession(false);

    if (sesion == null) {
        response.sendRedirect("login.jsp");
        return;
    }

    Usuario usuario = (Usuario) sesion.getAttribute("usuario");
    if (usuario == null) {
        response.sendRedirect("login.jsp");
        return;
    }

    // ✅ Leer filtros
    String estado = request.getParameter("estado");
    String prioridad = request.getParameter("prioridad");
    String categoria = request.getParameter("categoria");
    String fechaDesde = request.getParameter("fechaDesde");
    String fechaHasta = request.getParameter("fechaHasta");

    List<Tarea> tareas;

    if ("admin".equalsIgnoreCase(usuario.getRol())) {
        // ✅ Admin: ver TODAS las tareas
        tareas = tareaDAO.listarTodasConFiltros(
            estado, prioridad, categoria, fechaDesde, fechaHasta
        );
    } else {
        // ✅ Usuario normal: solo sus tareas
        tareas = tareaDAO.listarPorUsuarioConFiltros(
            usuario.getId(), estado, prioridad, categoria, fechaDesde, fechaHasta
        );
    }
if ("admin".equalsIgnoreCase(usuario.getRol())) {
    // Obtener lista de usuarios activos para el formulario de asignación
    com.tareas.model.UsuarioDAO usuarioDAO = new com.tareas.model.UsuarioDAO();
    List<com.tareas.model.Usuario> usuarios = usuarioDAO.obtenerUsuariosActivos();
    request.setAttribute("usuarios", usuarios);
}

    request.setAttribute("tareas", tareas);
    request.getRequestDispatcher("tareas.jsp").forward(request, response);
}
}


