package com.tareas.controller;

import com.tareas.model.Tarea;
import com.tareas.model.TareaDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import com.tareas.model.Usuario;

@WebServlet("/ActualizarTareaServlet")
public class ActualizarTareaServlet extends HttpServlet {

    private TareaDAO tareaDAO = new TareaDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        String titulo = request.getParameter("titulo");
        String descripcion = request.getParameter("descripcion");
        String fechaVencimiento = request.getParameter("fechaVencimiento");
        String estado = request.getParameter("estado");
        String prioridad = request.getParameter("prioridad");
        String categoria = request.getParameter("categoria");

        Tarea tarea = new Tarea();
        tarea.setId(id);
        tarea.setTitulo(titulo);
        tarea.setDescripcion(descripcion);
        tarea.setFechaVencimiento(fechaVencimiento);
        tarea.setEstado(estado);
        tarea.setPrioridad(prioridad);
        tarea.setCategoria(categoria);
        
        HttpSession sesion = request.getSession();
String rol = (String) sesion.getAttribute("rol");

if ("admin".equals(rol)) {
    String usuarioIdParam = request.getParameter("usuarioId");
int usuarioId;

if (usuarioIdParam != null && !usuarioIdParam.isEmpty()) {
    usuarioId = Integer.parseInt(usuarioIdParam);
} else {
    String idUsuarioOculto = request.getParameter("idUsuario");
    usuarioId = Integer.parseInt(idUsuarioOculto);
}

tarea.setIdUsuario(usuarioId);




} else {
    // El usuario normal solo puede actualizar sus propias tareas
    Usuario usuario = (Usuario) sesion.getAttribute("usuario");
tarea.setIdUsuario(usuario.getId());

}

        boolean actualizado = tareaDAO.actualizar(tarea);

        if (actualizado) {
            response.sendRedirect("TareaServlet");
        } else {
            request.setAttribute("mensaje", "Error al actualizar tarea");
            request.getRequestDispatcher("editar_tarea.jsp").forward(request, response);
        }
    }
}

