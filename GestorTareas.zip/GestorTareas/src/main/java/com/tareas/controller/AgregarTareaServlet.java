package com.tareas.controller;

import com.tareas.model.Tarea;
import com.tareas.model.TareaDAO;
import com.tareas.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/AgregarTareaServlet")
public class AgregarTareaServlet extends HttpServlet {

    private TareaDAO tareaDAO = new TareaDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // ✅ Validar sesión
        HttpSession sesion = request.getSession(false);
        if (sesion == null || sesion.getAttribute("usuario") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        Usuario usuario = (Usuario) sesion.getAttribute("usuario");

        // ✅ Obtener datos del formulario
        String titulo = request.getParameter("titulo");
        String descripcion = request.getParameter("descripcion");
        String fechaVencimiento = request.getParameter("fechaVencimiento");
        String estado = request.getParameter("estado");
        String prioridad = request.getParameter("prioridad");
        String categoria = request.getParameter("categoria");
int usuarioAsignadoId;

if ("admin".equalsIgnoreCase(usuario.getRol())) {
    try {
        usuarioAsignadoId = Integer.parseInt(request.getParameter("usuarioId"));
    } catch (NumberFormatException e) {
        request.setAttribute("mensaje", "Usuario seleccionado no es válido.");
        request.getRequestDispatcher("agregar_tarea.jsp").forward(request, response);
        return;
    }
} else {
    usuarioAsignadoId = usuario.getId();
}

        // ✅ Crear objeto Tarea
        Tarea tarea = new Tarea();
        tarea.setTitulo(titulo);
        tarea.setDescripcion(descripcion);
        tarea.setFechaVencimiento(fechaVencimiento);
        tarea.setEstado(estado);
        tarea.setPrioridad(prioridad);
        tarea.setCategoria(categoria);
        tarea.setIdUsuario(usuarioAsignadoId);

        // ✅ Guardar tarea en BD
        boolean insertado = tareaDAO.agregar(tarea);

        if (insertado) {
            // ✅ Si se guardó bien, redirige a lista de tareas
            response.sendRedirect("TareaServlet");
        } else {
            // ✅ Si falla, vuelve al formulario con mensaje de error
            request.setAttribute("mensaje", "Error al guardar tarea");
            request.getRequestDispatcher("agregar_tarea.jsp").forward(request, response);
        }
    }
}


