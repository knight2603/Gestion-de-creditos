package com.tareas.controller;

import com.tareas.model.Usuario;
import com.tareas.model.UsuarioDAO;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/RegistroServlet")
public class RegistroServlet extends HttpServlet {

    private UsuarioDAO usuarioDAO = new UsuarioDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String nombre = request.getParameter("nombre");
        String correo = request.getParameter("correo");
        String clave = request.getParameter("clave");
        String confirmarClave = request.getParameter("confirmarClave");

if (!clave.equals(confirmarClave)) {
    request.setAttribute("mensaje", "Las contraseñas no coinciden.");
    request.getRequestDispatcher("registrar.jsp").forward(request, response);
    return;
}


        
       if (!correo.matches("^(?=[a-zA-Z0-9._%+-]*[a-zA-Z])[a-zA-Z0-9._%+-]+@gmail\\.com$")) {
    request.setAttribute("mensaje", "Correo electronico invalido.");
    request.getRequestDispatcher("registrar.jsp").forward(request, response);
    return;
}

        if (usuarioDAO.existeCorreo(correo)) {
    request.setAttribute("mensaje", "Este correo ya está registrado.");
    request.getRequestDispatcher("registrar.jsp").forward(request, response);
    return;
}


        Usuario usuario = new Usuario();
        usuario.setNombre(nombre);
        usuario.setCorreo(correo);
        usuario.setClave(clave);

        boolean registrado = usuarioDAO.registrar(usuario);

        if (registrado) {
            response.sendRedirect("login.jsp?registro=exitoso");
        } else {
            request.setAttribute("mensaje", "Error al registrar usuario");
            request.getRequestDispatcher("registro.jsp").forward(request, response);
        }
    }
}


