package com.tareas.controller;

import com.tareas.model.Usuario;
import com.tareas.model.UsuarioDAO;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private UsuarioDAO usuarioDAO = new UsuarioDAO();

    // Maneja accesos GET (por ejemplo, si alguien entra directo por el navegador)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Redirige al formulario de inicio de sesión
        response.sendRedirect("login.jsp");
    }

    // Maneja el envío del formulario (POST)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String correo = request.getParameter("correo");
        String clave = request.getParameter("clave");

        // Llama al DAO para validar el usuario
        Usuario usuario = usuarioDAO.validar(correo, clave);

        if (usuario != null) {
            if ("activo".equalsIgnoreCase(usuario.getEstado())) {
            // Usuario válido → Crear sesión y redirigir
            HttpSession sesion = request.getSession();
            sesion.setAttribute("usuario", usuario);
            sesion.setAttribute("rol", usuario.getRol()); 
            response.sendRedirect("TareaServlet");
            } else {
        // Usuario está inactivo
        request.setAttribute("mensaje", "Tu cuenta está desactivada. Contacta al administrador.");
        request.getRequestDispatcher("login.jsp").forward(request, response);
    }
        } else {
            // Usuario no válido → Enviar mensaje de error y volver al login
            request.setAttribute("mensaje", "Usuario o contraseña incorrectos");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}








