package com.tareas.controller;

import com.tareas.model.Tarea;
import com.tareas.model.TareaDAO;
import com.tareas.model.Usuario;
import com.tareas.model.UsuarioDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/EditarTareaServlet")
public class EditarTareaServlet extends HttpServlet {

    private TareaDAO tareaDAO = new TareaDAO();
    private UsuarioDAO usuarioDAO = new UsuarioDAO(); // nuevo

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession sesion = request.getSession(false);
        if (sesion == null || sesion.getAttribute("usuario") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        Usuario usuario = (Usuario) sesion.getAttribute("usuario");
        sesion.setAttribute("rol", usuario.getRol());
        
        String idParam = request.getParameter("id");
        int id = Integer.parseInt(idParam);

        Tarea tarea = tareaDAO.buscarPorId(id);

        request.setAttribute("tarea", tarea);
        request.setAttribute("usuario", usuario); // importante para el <c:if>

        if ("admin".equalsIgnoreCase(usuario.getRol())) {
            List<Usuario> usuarios = usuarioDAO.obtenerUsuariosActivos();
            request.setAttribute("usuarios", usuarios);
        }

        request.getRequestDispatcher("editar_tarea.jsp").forward(request, response);
    }
}

