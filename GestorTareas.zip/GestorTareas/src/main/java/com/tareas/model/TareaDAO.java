package com.tareas.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class TareaDAO {

    // Listar tareas por ID de usuario
    public List<Tarea> listarPorUsuario(int idUsuario) {
        List<Tarea> lista = new ArrayList<>();
        String sql = "SELECT * FROM tareas WHERE id_usuario = ?";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Tarea t = new Tarea();
                t.setId(rs.getInt("id"));
                t.setTitulo(rs.getString("titulo"));
                t.setDescripcion(rs.getString("descripcion"));
                t.setFechaVencimiento(rs.getString("fecha_vencimiento"));
                t.setEstado(rs.getString("estado"));
                t.setPrioridad(rs.getString("prioridad"));
                t.setCategoria(rs.getString("categoria"));
                t.setIdUsuario(rs.getInt("id_usuario"));

                lista.add(t);
            }

        } catch (SQLException e) {
            System.out.println("Error al listar tareas: " + e.getMessage());
            e.printStackTrace();
        }

        return lista;
    }

    // ✅ Agregar nueva tarea
    public boolean agregar(Tarea tarea) {
        boolean insertado = false;

        String sql = "INSERT INTO tareas (titulo, descripcion, fecha_vencimiento, estado, prioridad, categoria, id_usuario) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, tarea.getTitulo());
            ps.setString(2, tarea.getDescripcion());
            ps.setString(3, tarea.getFechaVencimiento());
            ps.setString(4, tarea.getEstado());
            ps.setString(5, tarea.getPrioridad());
            ps.setString(6, tarea.getCategoria());
            ps.setInt(7, tarea.getIdUsuario());

            int filas = ps.executeUpdate();
            insertado = filas > 0;

        } catch (SQLException e) {
            System.out.println("Error al agregar tarea: " + e.getMessage());
            e.printStackTrace();
        }

        return insertado;
    }
    public Tarea buscarPorId(int id) {
    Tarea tarea = null;

    String sql = "SELECT * FROM tareas WHERE id = ?";

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            tarea = new Tarea();
            tarea.setId(rs.getInt("id"));
            tarea.setTitulo(rs.getString("titulo"));
            tarea.setDescripcion(rs.getString("descripcion"));
            tarea.setFechaVencimiento(rs.getString("fecha_vencimiento"));
            tarea.setEstado(rs.getString("estado"));
            tarea.setPrioridad(rs.getString("prioridad"));
            tarea.setCategoria(rs.getString("categoria"));
            tarea.setIdUsuario(rs.getInt("id_usuario"));
        }

    } catch (Exception e) {
        System.out.println("Error al buscar tarea: " + e.getMessage());
    }

    return tarea;
}
public boolean actualizar(Tarea tarea) {
    boolean actualizado = false;

    String sql = "UPDATE tareas SET titulo=?, descripcion=?, fecha_vencimiento=?, estado=?, prioridad=?, categoria=?, id_usuario=? WHERE id=?";

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, tarea.getTitulo());
        ps.setString(2, tarea.getDescripcion());
        ps.setString(3, tarea.getFechaVencimiento());
        ps.setString(4, tarea.getEstado());
        ps.setString(5, tarea.getPrioridad());
        ps.setString(6, tarea.getCategoria());
        ps.setInt(7, tarea.getIdUsuario()); 
        ps.setInt(8, tarea.getId());

        int filas = ps.executeUpdate();
        actualizado = filas > 0;

    } catch (Exception e) {
        System.out.println("Error al actualizar tarea: " + e.getMessage());
    }

    return actualizado;
}
public boolean eliminar(int id) {
    boolean eliminado = false;

    String sql = "DELETE FROM tareas WHERE id = ?";

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, id);

        int filas = ps.executeUpdate();
        eliminado = filas > 0;

    } catch (Exception e) {
        System.out.println("Error al eliminar tarea: " + e.getMessage());
    }

    return eliminado;
}
public List<Tarea> listarPorUsuarioConFiltros(
        int idUsuario, String estado, String prioridad,
        String categoria, String fechaDesde, String fechaHasta) {

    List<Tarea> lista = new ArrayList<>();

    StringBuilder sql = new StringBuilder("SELECT * FROM tareas WHERE id_usuario = ?");
    List<Object> parametros = new ArrayList<>();
    parametros.add(idUsuario);

    if (estado != null && !estado.isEmpty()) {
        sql.append(" AND estado = ?");
        parametros.add(estado);
    }

    if (prioridad != null && !prioridad.isEmpty()) {
        sql.append(" AND prioridad = ?");
        parametros.add(prioridad);
    }

    if (categoria != null && !categoria.isEmpty()) {
        sql.append(" AND categoria LIKE ?");
        parametros.add("%" + categoria + "%");
    }

    if (fechaDesde != null && !fechaDesde.isEmpty() && fechaHasta != null && !fechaHasta.isEmpty()) {
        sql.append(" AND fecha_vencimiento BETWEEN ? AND ?");
        parametros.add(fechaDesde);
        parametros.add(fechaHasta);
    }

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql.toString())) {

        for (int i = 0; i < parametros.size(); i++) {
            ps.setObject(i + 1, parametros.get(i));
        }

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Tarea t = new Tarea();
            t.setId(rs.getInt("id"));
            t.setTitulo(rs.getString("titulo"));
            t.setDescripcion(rs.getString("descripcion"));
            t.setFechaVencimiento(rs.getString("fecha_vencimiento"));
            t.setEstado(rs.getString("estado"));
            t.setPrioridad(rs.getString("prioridad"));
            t.setCategoria(rs.getString("categoria"));
            t.setIdUsuario(rs.getInt("id_usuario"));

            lista.add(t);
        }

    } catch (Exception e) {
        System.out.println("Error al listar tareas con filtros: " + e.getMessage());
        e.printStackTrace();
    }

    return lista;
}
public List<Tarea> listarTodasConFiltros(
    String estado, String prioridad,
    String categoria, String fechaDesde, String fechaHasta) {

    List<Tarea> lista = new ArrayList<>();

    StringBuilder sql = new StringBuilder(
        "SELECT t.*, u.nombre AS usuarioNombre, u.correo AS usuarioCorreo " +
        "FROM tareas t " +
        "INNER JOIN usuarios u ON t.id_usuario = u.id " +
        "WHERE 1=1"
    );

    List<Object> parametros = new ArrayList<>();

    if (estado != null && !estado.isEmpty()) {
        sql.append(" AND t.estado = ?");
        parametros.add(estado);
    }
    if (prioridad != null && !prioridad.isEmpty()) {
        sql.append(" AND t.prioridad = ?");
        parametros.add(prioridad);
    }
    if (categoria != null && !categoria.isEmpty()) {
        sql.append(" AND t.categoria LIKE ?");
        parametros.add("%" + categoria + "%");
    }
    if (fechaDesde != null && !fechaDesde.isEmpty() && fechaHasta != null && !fechaHasta.isEmpty()) {
        sql.append(" AND t.fecha_vencimiento BETWEEN ? AND ?");
        parametros.add(fechaDesde);
        parametros.add(fechaHasta);
    }

    sql.append(" ORDER BY u.nombre, t.id");

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql.toString())) {

        for (int i = 0; i < parametros.size(); i++) {
            ps.setObject(i + 1, parametros.get(i));
        }

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Tarea t = new Tarea();
            t.setId(rs.getInt("id"));
            t.setTitulo(rs.getString("titulo"));
            t.setDescripcion(rs.getString("descripcion"));
            t.setFechaVencimiento(rs.getString("fecha_vencimiento"));
            t.setEstado(rs.getString("estado"));
            t.setPrioridad(rs.getString("prioridad"));
            t.setCategoria(rs.getString("categoria"));
            t.setIdUsuario(rs.getInt("id_usuario"));

            t.setUsuarioNombre(rs.getString("usuarioNombre"));
            t.setUsuarioCorreo(rs.getString("usuarioCorreo"));

            lista.add(t);
        }

    } catch (Exception e) {
        System.out.println("Error al listar TODAS las tareas con filtros: " + e.getMessage());
        e.printStackTrace();
    }

    return lista;
}
public Map<String, Integer> obtenerConteoPorEstado() {
    Map<String, Integer> resultado = new HashMap<>();

    String sql = "SELECT estado, COUNT(*) AS cantidad FROM tareas GROUP BY estado";

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            String estado = rs.getString("estado");
            int cantidad = rs.getInt("cantidad");
            resultado.put(estado, cantidad);
        }

    } catch (Exception e) {
        System.out.println("Error al obtener conteo por estado: " + e.getMessage());
        e.printStackTrace();
    }

    return resultado;
}


}




