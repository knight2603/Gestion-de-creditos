package com.tareas.model;

public class Usuario {
    private int id;
    private String correo;
    private String clave;
    private String nombre;
    private String rol;
    private String estado;

    // Constructor vacío
    public Usuario() {
    }

    // Constructor con parámetros
    public Usuario(int id, String correo, String clave, String nombre) {
        this.id = id;
        this.correo = correo;
        this.clave = clave;
        this.nombre = nombre;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
         this.rol = rol;
   }
   public String getEstado() {
        return estado;
   }

   public void setEstado(String estado) {
          this.estado = estado;
   }
}

