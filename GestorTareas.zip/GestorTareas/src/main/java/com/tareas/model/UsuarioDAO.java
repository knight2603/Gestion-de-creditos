package com.tareas.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;

public class UsuarioDAO {

    public Usuario validar(String correo, String clave) {
        Usuario usuario = null;

        try {
            Connection con = Conexion.conectar();
            String sql = "SELECT * FROM usuarios WHERE correo = ? AND clave = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, correo);
            ps.setString(2, clave);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                usuario = new Usuario();
                usuario.setId(rs.getInt("id"));
                usuario.setCorreo(rs.getString("correo"));
                usuario.setClave(rs.getString("clave"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setRol(rs.getString("rol"));
                usuario.setEstado(rs.getString("estado")); 
            }

        } catch (Exception e) {
            System.out.println("Error al validar usuario: " + e.getMessage());
        }

        return usuario;
    }
    public boolean registrar(Usuario usuario) {
        boolean registrado = false;

        try {
            Connection con = Conexion.conectar();
            String sql = "INSERT INTO usuarios (nombre, correo, clave) VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getCorreo());
            ps.setString(3, usuario.getClave());

            int filas = ps.executeUpdate();
            if (filas > 0) {
                registrado = true;
            }
        } catch (Exception e) {
            System.out.println("Error al registrar usuario: " + e.getMessage());
        }

        return registrado;
    }
    public boolean existeCorreo(String correo) {
    boolean existe = false;
    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement("SELECT id FROM usuarios WHERE correo = ?")) {
        ps.setString(1, correo);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            existe = true;
        }
    } catch (Exception e) {
        System.out.println("Error al verificar correo: " + e.getMessage());
    }
    return existe;
}
public List<Usuario> obtenerTodos() {
    List<Usuario> lista = new ArrayList<>();
    String sql = "SELECT * FROM usuarios ORDER BY id";

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            Usuario u = new Usuario();
            u.setId(rs.getInt("id"));
            u.setNombre(rs.getString("nombre"));
            u.setCorreo(rs.getString("correo"));
            u.setRol(rs.getString("rol"));
            u.setEstado(rs.getString("estado"));
            lista.add(u);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return lista;
}
public void convertirEnAdmin(int id) {
    String sql = "UPDATE usuarios SET rol = 'admin' WHERE id = ?";

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, id);
        ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    }
}
public void eliminarUsuario(int id) {
    String sql = "DELETE FROM usuarios WHERE id = ?";

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, id);
        ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    }
}
public void convertirEnUsuario(int id) {
    String sql = "UPDATE usuarios SET rol = 'usuario' WHERE id = ?";

    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, id);
        ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    }
}
public void cambiarEstado(int idUsuario, String nuevoEstado) {
    String sql = "UPDATE usuarios SET estado = ? WHERE id = ?";
    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, nuevoEstado);
        ps.setInt(2, idUsuario);
        ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    }
}

public boolean tieneTareas(int idUsuario) {
    String sql = "SELECT COUNT(*) FROM tareas WHERE id_usuario = ?";
    try (Connection con = Conexion.conectar();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, idUsuario);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getInt(1) > 0;
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}
public List<Usuario> obtenerUsuariosActivos() {
    List<Usuario> usuarios = new ArrayList<>();
    String sql = "SELECT * FROM usuarios WHERE estado = 'activo'";

    try (Connection conn = Conexion.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            Usuario u = new Usuario();
            u.setId(rs.getInt("id"));
            u.setNombre(rs.getString("nombre"));
            u.setCorreo(rs.getString("correo"));
            u.setRol(rs.getString("rol"));
            u.setEstado(rs.getString("estado"));
            usuarios.add(u);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return usuarios;
}

}


